import GymLayout from "@/components/gym-layout"

export default function DashboardLayout({ children }) {
  return <GymLayout>{children}</GymLayout>
}
