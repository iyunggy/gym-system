# Django project initialization
